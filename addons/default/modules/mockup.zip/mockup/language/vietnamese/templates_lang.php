<?php
$lang['design:manages_layer']                       = 'Manage Layers';
$lang['design:add_your_image']						 = "Add Your Image ";
$lang['design:add_your_own_text']						 = "Add Your Own Text ";
$lang['design:invalid_mockup_size']						 = "Sorry! But the uploaded image size does not conform our indication of size.\\n Minimum size 1200x1200 and Maximum 3600x3600";
$lang['design:add_mockup']					= 'Add Your Art';