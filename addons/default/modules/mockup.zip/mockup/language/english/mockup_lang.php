<?php defined('BASEPATH') OR exit('No direct script access allowed');


//lable
$lang['cp:nav_mockup']                       = 'Mockups';
$lang['mockup:mockup_name']					="Mockup Name";
$lang['mockup:mockup_title']				="Mockups";
$lang['mockup:mockup_price']				="Price";
$lang['mockup:mockup_position']="Position";
$lang['mockup:mockup_type']="Type";
$lang['mockup:attributes']="Mockup";
$lang['mockups:add_title']="Add Mockup";
$lang["mockup:category_label"]="Category";
$lang["mockup:status"]="Status";
$lang["mockup:inactive"]="Inactive";
$lang["mockup:active"]="Active";
$lang["mockup:date_label"]="Date";
$lang["mockup:description_lable"]="Descriptions";
$lang["mockup:edit_title"]="Edit Mockup";
$lang["mockup:create_title"]="Create Mockup";
//tabs
$lang['mockup:information']="Information";
$lang['mockup:combinations']="Combinations";
$lang['mockup:images']="Images";

//forms
$lang['mockups:images']="Images";


//message
$lang['mockup:save_product_before_add_image']="You must save this product before adding images. ";
$lang['mockup:save_product_before_add_combinations']= "You must save this product before adding combinations.";
$lang['mockup:currently_no_mockups']						 = "There are no mockups at the moment";
$lang['mockup:no_mockup_found']						 = "No Mockup found";