<div class="fpd-views-related fpd-grid-contain fpd-clearfix fpd-tr "
	style="display: block;">
	<div
		class="fpd-shadow-1 fpd-item  fpd-view-active">
		<picture
			style="background-image: url(uploads/default/../template/8_104.png);"></picture>
	</div>
	<div class="fpd-shadow-1 fpd-item  ">
		<picture
			style="background-image: url(uploads/default/../template/8_105.png);"></picture>
	</div>
</div>