
<div class="fpd-context-dialog fpd-shadow-2 fpd-columns-3"
	data-columns="3">
	<nav class="fpd-dialog-head fpd-clearfix fpd-primary-bg-color fpd-primary-text-color">
		<div class="fpd-left fpd-dialog-drag-handle">
			<div>
				<i class="fpd-icon-drag"></i><span class="fpd-dialog-title"></span>
			</div>
		</div>
		<div class="fpd-right">
			<div class="fpd-content-back fpd-btn">
				<i class="fpd-icon-back"></i>
			</div>
			<div class="fpd-close-dialog fpd-btn">
				<i class="fpd-icon-close"></i>
			</div>
		</div>
	</nav>
	<div class="fpd-dialog-content">

			<!-- Manage Layers -->
			<div class="fpd-content-layers">
				<div class="fpd-list"></div>
			</div>
	</div>
</div>

