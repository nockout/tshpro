<?php
$lang['template:manages_layer']                       = 'Manage Layers';
$lang['template:add_your_image']						 = "Add Your Image ";
$lang['template:add_your_own_text']						 = "Add Your Own Text ";
$lang['template:invalid_mockup_size']						 = "Sorry! But the uploaded image size does not conform our indication of size.\\n Minimum size 1200x1200 and Maximum 4800x4800";
$lang['template:add_mockup']					= 'Add Your Art';
$lang['template:choose_product']='Choose Product';
$lang['template:manages_layer']='Layers';
$lang['template:choose_product']='Choose Product';
$lang['template:enter_text']='Enter your text';
$lang['template:functions']='Features';
$lang['template:change_product']='Choose product';


