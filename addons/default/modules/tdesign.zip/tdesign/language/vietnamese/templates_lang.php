<?php
$lang['template:manages_layer']                       = 'Quản lý layer';
$lang['template:add_your_image']						 = "Thêm hình";
$lang['template:add_your_own_text']						 = "Thêm text ";
$lang['template:invalid_mockup_size']						 = "Hiện tại hệ thống chỉ cho phép upload Logo với .\\n kích thước nhỏ nhất 1200x1200 và lớn nhất là 4800x4800";
$lang['template:add_mockup']					= 'Thêm logo';

$lang['template:choose_product']='Chọn sản phẩm ';
$lang['template:manages_layer']='Layer';
$lang['template:enter_text']='Thêm text';
$lang['template:functions']='Arts';

$lang['template:change_product']='Đổi sản phẩm ';
