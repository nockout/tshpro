<?php defined('BASEPATH') or exit('No direct script access allowed');


class Module_TDesign extends Module {

	public $version = '1.0.0';

	public function info()
	{
		return array(
			'name' => array(
				'en' => 'Design',
				'vn' => 'Thiết kế mẫu'
			),
			'description' => array(
				'en' => 'Design new pattern',
				'vn' => 'Thiết kế'
			),
			'frontend' => false,
			'backend'  => true,
			'menu'	  => 'design',
			'is_core' =>true,
				
		);
	}

	
	public function install()
	{
		//$this->dbforge->drop_table('permissions');

// 		$tables = array(
// 			'permissions' => array(
// 				'id' => array('type' => 'INT', 'constraint' => 11, 'auto_increment' => true, 'primary' => true,),
// 				'group_id' => array('type' => 'INT', 'constraint' => 11, 'key' => true),
// 				'module' => array('type' => 'VARCHAR', 'constraint' => 50,),
// 				'roles' => array('type' => 'TEXT', 'null' => true,),
// 			),
// 		);

// 		if ( ! $this->install_tables($tables))
// 		{
// 			return false;
// 		}

		return true;
	}

	public function uninstall()
	{
		// This is a core module, lets keep it around.
		return true;
	}

	public function upgrade($old_version)
	{
		return true;
	}

}