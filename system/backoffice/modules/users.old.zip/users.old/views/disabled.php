<h2 class="page-title" id="page_title"><?php echo lang('user:register_header') ?></h2>

<div class="notice-box">
	<?php echo $this->lang->line('user:registration_disabled') ?>
</div>