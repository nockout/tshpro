<h2 class="page-title"><?php echo lang('user:password_reset_title')?></h2>

<div class="success-box">
    <?php echo lang('user:password_reset_message') ?>
</div>