<?php defined('BASEPATH') or exit('No direct script access allowed');

 /**
 * Swedish translation.
 *
 * @author		marcus@incore.se
 * @package		PyroCMS  
 * @link		http://pyrocms.com
 * @date		2012-10-22
 * @version		1.1.0
 */

$lang['users:role_admin_profile_fields'] = 'Adminstratörsfält';


/* End of file permission_lang.php */  
/* Location: system/cms/modules/users/language/swedish/permission_lang.php */  
