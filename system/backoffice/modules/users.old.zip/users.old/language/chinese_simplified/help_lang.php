<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "<h4>概观</h4>
<p>用户模块的工作原理与组和权限一起给PyroCMS的
访问控制。</p>

<h4>添加用户</h4>
<p>填写用户的详细信息（包括密码），并保存。如果你有
在设置电子邮件中启用激活邮件将发送到新用户
激活链接。</p>

<h4>激活新用户</h4>
<p>如果激活邮件设置上注册的用户被禁用
网站前端下会出现“无效用户”菜单项，直到你
批准或删除其帐户。如果激活邮件启用用户
默默注册，无需管理员的帮助。</p>"; #translate