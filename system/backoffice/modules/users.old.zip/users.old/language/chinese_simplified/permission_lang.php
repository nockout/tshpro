<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Chinese Simpplified translation.
 *
 * @author		Kefeng DENG
 * @package		PyroCMS
 * @subpackage 	Users Module
 * @category	Modules
 * @link		http://pyrocms.com
 * @date		2012-06-27
 * @version		1.0
 */

$lang['users:role_admin_profile_fields'] = '管理员的栏目'; #translate