<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['users:role_admin_profile_fields'] = 'Gerenciar Campos de Perfil';