<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Ion Auth Lang - Dutch
*
* Author: Diederik Eijgelaar
* 		  diederik.eijgelaar@gmail.com
*
* Description:  Dutch language file for Ion Auth messages and errors
*
*/

// Account Creation
$lang['account_creation_successful'] 	= 'Account is aangemaakt';
$lang['account_creation_unsuccessful'] 	= 'Kon account niet aanmaken';
$lang['account_creation_duplicate_email'] 	 = 'Ongeldig of reeds bestaande email';
$lang['account_creation_duplicate_username'] = 'Ongeldige of reeds bestaande gebruikersnaam';


// Password
$lang['password_change_successful'] 	= 'Wachtwoord is gewijzigd';
$lang['password_change_unsuccessful'] 	= 'Kon wachtwoord niet wijzigen';
$lang['forgot_password_successful'] 	= 'Wachtwoord reset mail verzonden';
$lang['forgot_password_unsuccessful'] 	= 'Kon wachtwoord niet resetten';

// Activation
$lang['activate_successful'] 		= 'Account geactiveerd';
$lang['activate_unsuccessful'] 		= 'Kon account niet activeren';
$lang['deactivate_successful'] 		= 'Account gedeactiveerd';
$lang['deactivate_unsuccessful'] 	= 'Kon account niet deactiveren';
$lang['activation_email_successful'] 	= 'Activatiemail verzonden';
$lang['activation_email_unsuccessful'] 	= 'Kon Activatiemail niet verzenden';

// Login / Logout
$lang['login_successful'] 		= 'Ingelogd';
$lang['login_unsuccessful'] 		= 'Incorrecte login';
$lang['logout_successful'] 		= 'Uitgelogd';

// Account Changes
$lang['update_successful'] 		= 'Accountinformatie is opgeslagen';
$lang['update_unsuccessful'] 		= 'Acccountinformatie kon niet worden opgeslagen';
$lang['delete_successful'] 		= 'Gebruiker verwijderd';
$lang['delete_unsuccessful'] 		= 'Kon Gebruiker niet verwijderen';


?>
